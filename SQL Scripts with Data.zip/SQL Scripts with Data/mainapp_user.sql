-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: mainapp
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userid` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `role` varchar(500) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(200) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(500) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `zipcode` varchar(200) NOT NULL,
  `createdat` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('1eab8aac-9733-4efe-8d96-eda389982146','admin','Sheriff','m','admin','devadharshini797+ssheriff@gmail.com','333-456-7890','Zuko@7997','123 clearance Street','Unit 9','Roxbury','Massachu','M1L 2E9',NULL,'Albania'),('3a8c2919-1551-4102-a789-3704498467d0','anju','qeq','dsf','user','ddd@d.c','123-456-7890','Zuko@7997','werqwe','dwqe','qeqw','were','m1l 2e9',NULL,'Burkina Faso'),('6f04edaa-0881-47a3-8610-f4c70fac8977','demo','sdfdsa','sdfdsf','user','devadharshini797@GMAIL.COM','123-345-6789','ZUKO@7997','SDFSD','SDFDS','SHBA','ON','M1L 2E9','Thu Apr 27 2023 20:39:06 GMT-0400 (Eastern Daylight Time)','Canada'),('6370adc6-f87e-4328-a2c5-36add51674cf','deva','Devadharshini','NN','user','devadharshini797@gmail.com','122-345-6788','Zuko@7997','2 valdane Dr','sdf','Woodstock','ON','m1l 2e9',NULL,'USA'),('7e027fed-a89b-4dcf-ab09-2b70d09feeaf','raff','Rifaya','rewr','user','dd@g.c','123-456-7890','Zuko@7997','wefsr','sdfw','sdfsd','on','m1l 2e9',NULL,'USA');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-20 19:23:30
