-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: products
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userid` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `role` varchar(500) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(200) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(500) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `zipcode` varchar(200) NOT NULL,
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('sephora-7732248b-539c-48f7-937f-ef24df1be752','eadmin','eskincare Sheriff','Mahaboob','admin','devadharshini797+ssheriff@gmail.com','333-456-7890','Zuko@7997','123 clearance Street','Unit 7','Roxbury','Massachutes','M1L 2E9','eskincare'),('sephora-060285c7-99aa-4842-9302-c0811095a631','edeva','Deva','Nagarajan','manager','deva@d.cd','123-456-7890','Zuko@7997','New Adr 1',NULL,'Toronto','ON','m1l 2e9','eskincare'),('sephora-ec7d7cf8-167f-46e3-919c-7ad925e54406','sadmin','Sheriff','Mahaboob','admin','devadharshini797+ssheriff@gmail.com','333-456-7890','Zuko@7997','123 clearance Street','Unit 7','Roxbury','Massachutes','M1L 2E9','sephora'),('sephora-1207e1cf-7569-464b-beab-e7131645eef4','sbalaji','balaji Chalam','B2','manager','b2@g.c','333-444-5555','Zuko@7997','asdaw','werew','asdfa','were','m1l 2e9','sephora'),('sephora-67d14269-e6ce-4279-979b-5ac14f8ea817','sdeva','Devadharshini N','Nagarajan','manager','devadharshini797@gmail.com','333-456-7890','Zuko@7997','2 valdane','Unit9','Scarborough','On','M1L 2E9','sephora'),('sephora-400bd2d2-b0c9-4c81-bc5a-aa7d15cc2bab','sgevi','Gevi','A','manager','gevi@f.c','123-456-7890','Zuko@7997','sdfsdf',NULL,'asfa','sdfds','m1l 2e9','sephora'),('sephora-15e5e1d3-00d6-4d8b-9624-b9bf0502d590','ssurya','Surya','Shankar','manager','surya@g.c','333-444-5555','Zuko@7997','sfs','sdfs','sfgs','on','m1l 2e9','sephora'),('sephora-d1855a94-9b36-4258-8e8a-731aa0f9c7c7','yadmin','yesstyle Sheriff','Mahaboob','admin','devadharshini797+ysheriff@gmail.com','333-456-7890','Zuko@7997','123 clearance Street','Unit 7','Roxbury','Massachutes','M1L 2E9','yesstyle'),('sephora-d41389ff-90e4-4260-8dd5-0cb89ac103c0','ydeva','yes Deva','N','manager','eva@g.c','789-999-9999','Zuko@7997','adeq','qweqwe','Toronto','ON','m1l 2e9','yesstyle'),('sephora-dd3c5833-a3ea-4d86-94e7-cf0acf74bba6','ysurya','Surya','KD','manager','kd@f.c','234-555-5555','Zuko@7997','efe','erwer','Woodstock','ON','m1l 2e9','yesstyle');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-20 19:23:30
