-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: mainapp
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchaseproducts`
--

DROP TABLE IF EXISTS `purchaseproducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaseproducts` (
  `purchaseid` varchar(255) NOT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `productid` varchar(255) DEFAULT NULL,
  `productname` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`purchaseid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaseproducts`
--

LOCK TABLES `purchaseproducts` WRITE;
/*!40000 ALTER TABLE `purchaseproducts` DISABLE KEYS */;
INSERT INTO `purchaseproducts` VALUES ('02bb16ef-79c8-45fa-a6e2-bbb265929f2b','Wed Apr 26 2023 23:39:28 GMT-0400 (Eastern Daylight Time)','deva','yesstyle-abb8ca48-7181-4259-8a02-440efd56f30c','Barrier+ Besties Hydrating and Nourishing Kit','Eye Creams'),('4862aaa3-9341-4914-a37a-d09a45962f14','Thu Apr 27 2023 11:33:19 GMT-0400 (Eastern Daylight Time)','anju','yesstyle-abb8ca48-7181-4259-8a02-440efd56f30c','Barrier+ Besties Hydrating and Nourishing Kit','Eye Creams'),('58febf10-a321-441e-9ee7-a4eb1fcc6a7a','Thu Apr 27 2023 20:44:25 GMT-0400 (Eastern Daylight Time)','deva','eskincare-df659552-0fc8-46d8-a691-ac41ba006182','Ultra Glow Serum: Glow + Strengthen Vitamin C Serum','Toners'),('93a2547f-0ad7-499d-8f29-c51c79520491','Mon Apr 24 2023 20:49:43 GMT-0400 (Eastern Daylight Time)','deva','sephora-de787d56-6ea2-4fd3-9033-f39b6e9c586e','Mini Plum Plump Hyaluronic Acid Moisturizer','Exfoliators'),('94853557-30e4-471c-86fa-2246f3c61f0f','Thu Apr 27 2023 10:12:28 GMT-0400 (Eastern Daylight Time)','anju','eskincare-99906c47-3514-404c-9b3b-31d0e476c8a8','Water Drench Hyaluronic Cloud Hydra-Gel Eye Patches','Eye Creams'),('a45d3b01-756d-4e2b-98ce-3bf18392ee32','Wed Apr 26 2023 18:03:56 GMT-0400 (Eastern Daylight Time)','raff','sephora-9ff948f3-2593-45aa-8bbc-13dfb4bf7429','Mini Watermelon Glow Niacinamide Dew Drops','Face Oils'),('a510cee7-395f-4593-a829-73fa1d7e3202','Wed Apr 26 2023 23:39:08 GMT-0400 (Eastern Daylight Time)','deva','yesstyle-db281b2e-2820-416f-a546-91d3e52b672f','Daily Dose Hydrating-Ceramide Boost + SPF 40 Sunscreen Oil PA+++','Sunscreen'),('fb3cc132-2f20-49e3-aabc-eea32585d65b','Thu Apr 27 2023 20:43:23 GMT-0400 (Eastern Daylight Time)','deva','eskincare-df659552-0fc8-46d8-a691-ac41ba006182','Ultra Glow Serum: Glow + Strengthen Vitamin C Serum','Toners'),('fde1acbe-60b0-429d-8a1d-2f841c44cac3','Wed Apr 26 2023 18:58:23 GMT-0400 (Eastern Daylight Time)','raff','yesstyle-db281b2e-2820-416f-a546-91d3e52b672f','Daily Dose Hydrating-Ceramide Boost + SPF 40 Sunscreen Oil PA+++','Sunscreen');
/*!40000 ALTER TABLE `purchaseproducts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-20 19:23:30
